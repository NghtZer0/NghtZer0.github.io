/**
 * @Author: 小红
 * @Date: 2023/1/11
 * @fileName: tag
 * @Description: 标签详情
 */


class Tag {
  constructor() {
  }
  
}

!(() => {
  document.addEventListener("DOMContentLoaded", () => window.TagClass = new Tag())
})();