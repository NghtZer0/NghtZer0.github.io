/**
 * @Author: 小红
 * @Date: 2023/1/11
 * @fileName: category
 * @Description: 分类详情
 */


class Category {
  constructor() {


  }

}

!(() => {
  document.addEventListener("DOMContentLoaded", () => window.CategoryClass = new Category())
})();